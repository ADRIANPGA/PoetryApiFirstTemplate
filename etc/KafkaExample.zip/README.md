# Zucca

María Álvarez Castelo - 2022
Web application for cooking recipes using MEAN stack

El proyecto describe una arquitectura basada en microservicios que realiza las siguientes tareas:

- Recopilación de datos externos de una API pública con un Kafka Producer
- Envío de los datos a través de Kafka con el Kafka Producer
- Lectura, tratamiento e inserción en una base de datos MongoDB de los datos con un Kafka Consumer
- API REST para gestionar la conexión a la base de datos y sus peticiones asociadas
- Aplicación web para la visualización e interacción con los datos

Para llevar a cabo todo el flujo de ejecución de la arquitectura completa se deben seguir los siguientes pasos:

1. Ejecutar el fichero 'docker-compose.yml' incluido en /docker-services/ con el comando

```bash
  docker-compose up
```
para el despliegue de los contenedores Kafka, ZooKeeper y MongoDB.

2. Ejecutar el Kafka Producer, contenido en /microservices/kafka-producer. La clase principal está en la ruta /src/main/java/com/zucca/kafkaproducer/KafkaProducerApplication.java

3. Ejecutar el Kafka Consumer, contenido en /microservices/kafka-consumer. Antes de ello, instalar las dependencias necesarias incluidas en el fichero 'requirements' en la ruta /resources, con el comando

```bash
  pip install -r requirements.txt
```

Se recomienda utilizar un entorno Python limpio para evitar incompatibilidades entre dependencias.

4. Instalar las dependencias del package.json y ejecutar el back-end (servidor node), con el comando
```bash
  npm run dev
  ```

5. Instalar las dependencias del package.json y ejecutar el front-end (React), con el comando
```bash
  npm start
  ```

6. La web está disponible en 'localhost:3000'