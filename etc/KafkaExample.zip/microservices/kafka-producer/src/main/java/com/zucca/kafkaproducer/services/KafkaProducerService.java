// Paquete
package com.zucca.kafkaproducer.services;

// Importaciones librerias
import org.json.JSONObject;
import org.slf4j.Logger;
import org.springframework.stereotype.Service;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.kafka.core.KafkaTemplate;
// Librerias para las peticiones a la API
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@Service
public class KafkaProducerService {
    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaProducerService.class);

    @Autowired
    MessageSource messageSource;
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Value("${kafka.topic}")
    private String topic;

    @Scheduled(fixedDelayString = "${fixedDelay.in.milliseconds}")
    public void sendMessageToKafka() {
        // Constantes para definir las recetas a obtener en cada peticion y que no se repitan
        String from = "0", size = "40";

        OkHttpClient client = new OkHttpClient();

        // Peticiones a la API, por cada vuelta se solicitan 40 objetos que pueden ser recetas o categorias
        for (int i = 0; i < 150; i++) {
            System.out.println("---------------------  MENSAJE " + i + " ---------------------");
            Request request = new Request.Builder()
                    .url("https://tasty.p.rapidapi.com/recipes/list?from=" + from + "&size=" + size)
                    .get()
                    .addHeader("X-RapidAPI-Key", "4b20955bdamshdc78c579b6e0d06p170047jsn4eabe5d061d2")
                    .addHeader("X-RapidAPI-Host", "tasty.p.rapidapi.com")
                    .build();

            try {
                Response response = client.newCall(request).execute();
                String message = response.body().string();
                JSONObject jsonObject = new JSONObject(message);
                // Por cada objeto obtenido, se recorren las recetas y se envian en mensajes separados al topic
                for (int j = 0; j < jsonObject.getJSONArray("results").length(); j++) {
                    JSONObject recipe = jsonObject.getJSONArray("results").getJSONObject(j);
                    kafkaTemplate.send(topic, recipe.toString());
                    // Mensaje de log por consola para ver el progreso
                    LOGGER.info(messageSource.getMessage("Mensaje enviado",
                            new String[] { KafkaProducerService.class.getSimpleName(), recipe.getString("name") },
                            LocaleContextHolder.getLocale()));                            
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Se incrementa la constante 'from' para obtener las siguientes 40 recetas
            from = String.valueOf(Integer.parseInt(from) + 40);
            System.out.println("++++++++++++++++++++++++++++++++++ FINALIZA +++++++++++++++++++++++++++++++++++++++++");
        }
    }

}
