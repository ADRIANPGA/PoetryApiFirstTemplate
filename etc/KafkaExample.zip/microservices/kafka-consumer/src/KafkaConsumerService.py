# Importaciones librerias
from kafka import KafkaConsumer
from pymongo import MongoClient
import pymongo
import json

# Conexion a la base de datos
try:
    connection = MongoClient(
        'mongodb://malvac10:malvaczucca@localhost:27017/?authSource=admin')
    db = connection.zucca
    print("Base de datos conectada")
except pymongo.errors.ConnectionFailure as error:
    print('No se pudo conectar a MongoDB: %s' % error)


# Se declara el consumer de Kafka
consumer = KafkaConsumer('recipesZucca', bootstrap_servers=['localhost:9092'])


# Tratamiento de datos e insercion en mongodb
def data_parser():
    # Se recorre cada mensaje publicado en el topic
    for msg in consumer:
        # Se carga el mensaje en formato json
        recipe = json.loads(msg.value)
        canonical_id = str(recipe['canonical_id'])
        try:

            # Si es una receta, se comprueba que no exista en la base de datos
            if "recipe" in canonical_id:
                same_recipe = db.recipes.find_one({'canonical_id': recipe['canonical_id']})
                # Si no existe:
                if same_recipe == None:
                    db.recipes.insert_one(recipe)
                    print()

            # Si es una categoria:
            elif "compilation" in canonical_id:
                # Se crea un documento para esa categoria
                document = {"compilation": recipe['name'], "recipes": []}
                # Se recorre cada receta de esa categoria
                for element in recipe['recipes']:
                    # Se busca la receta en la base de datos
                    same_recipe = db.recipes.find_one({'canonical_id': element['canonical_id']})
                    # Si no existe la receta, se añade en la coleccion de recetas:
                    if same_recipe == None:
                        # Si el campo _id ya existe tiene que ser eliminado para permitir a mongo autogenerar el suyo
                        if '_id' in element:
                            del element['_id']
                        data_inserted = db.recipes.insert_one(element)
                        document['recipes'].append(data_inserted.inserted_id)
                    # Si existe la receta, solo se añade la referencia al id en la categoria creada
                    else:
                        document['recipes'].append(same_recipe['_id'])
                db.compilations.insert_one(document)

        except Exception as inst:
            print("No se pudo insertar en MongoDB", inst)
            print(inst.args)


data_parser()
