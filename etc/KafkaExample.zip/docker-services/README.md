Docker-compose
============

Docker-compose.yml file with MongoDB, Kafka and Zookeeper images

## Usage
  To start the Docker Compose, run the following command: 
```bash
docker-compose up
```
To authenticate to the MongoDB database via console, use the following command:
```bash
mongo -u "malvac10" -p "malvacZucca" --authenticationDatabase "admin"
```
## Description
The following content corresponds to the MongoDB service: 
```yaml
  mongo:
    image: mongo:5.0.3
    container_name: mongo
    hostname: mongo
    restart: unless-stopped
    ports:
      - "27017:27017"
    environment:
      MONGO_INITDB_ROOT_USERNAME: malvac10
      MONGO_INITDB_ROOT_PASSWORD: malvaczucca
    volumes:
      - ./persistence/mongo/data:/data/db
      - ./persistence/mongo/log:/var/log/mongodb/
```

Kafka service: 
```yaml
 kafka:
    image: wurstmeister/kafka
    restart: unless-stopped
    ports:
      - "9092:9092"
    environment:
      KAFKA_ADVERTISED_HOST_NAME: 127.0.0.1
      KAFKA_CREATE_TOPICS: "recipes_topic:1:1"
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
```

Zookeeper service:
```yaml
  zookeeper:
    image: wurstmeister/zookeeper
    restart: unless-stopped
    ports:
      - "2181:2181"
```
